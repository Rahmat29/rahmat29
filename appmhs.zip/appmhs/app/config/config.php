<?php
define('base_url', 'http://localhost/appmhs');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_appmhs');
